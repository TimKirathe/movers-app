package com.moringaschool.moversapp;

public class Constants {

    public static final String BASE_URL = BuildConfig.BASE_URL;
}
