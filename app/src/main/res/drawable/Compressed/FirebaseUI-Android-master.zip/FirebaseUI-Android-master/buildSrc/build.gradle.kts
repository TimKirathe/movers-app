repositories {
    mavenCentral()
    jcenter()
}

plugins {
    `kotlin-dsl`
}
